# Pile Serveur Web PHP & MySQL (pour développement)

Le fichier .tar que ous venez d'extraire, permet de créer une Pile Serveur "_contenarisée_" équivalente à LAMP (_un serveur web sous GNU/Linux avec php et mysql_).

Ce dossier comporte l'évolution de mes "_tâtonnements_" entre la première version et le fichier **_`docker-compose.yml`_** final que vous pouvez utiliser librement dans l'étât ou adapter à votre guise.

Il ya dans ce dossier un fichier caché nommé "**_`.env`_**" qui contient les variable d'environnement du SGDBR dont voici ci-dessous les informations (_de connexion_) : <br><br>

```
MYSQL_ROOT_PASSWORD=mot2passeRoot
MYSQL_DATABASE=myapp
MYSQL_USER=monutilisateur
MYSQL_PASSWORD=mot2passUser
```
<br>

## Prérequis
- Installer "Docker" (voire Docker Desktop) sur votre machine
- Renommez le dossier **"`php-stack`"** au nom de votre projet (_éviter les espaces dans le nom du dossier_)
  - Créer un sous-dossier **"`app`"** et un autre sous-dossier **"`db`"** dans votre dossier projet
- Le fichier _`docker-compose.yml`_ doit être au même niveau que vos dossiers _`app`_ et _`db`_<br><br>

## Accès au site web et/ou à la base des données
- Pour accéder au site web avec un navigateur internet, il faut taper dans la barre d'adresses [localhost](http://localhost)
- Pour accéder à la base de données avec PHP-MyAdmin via un navigateur web, il faut taper l'adresse [localhost:8080](http://localhost:8080)

J'espère que cette "_stack_" vous sera utile.
